az group create -n 65-40d36c20-using-azure-service-bus-queues-with-c -l westus

az servicebus namespace create --n peerkasimservicebus -g servicebus

az servicebus namespace authorization-rule keys list `
 -g servicebus `
   --namespace-name peerkasimservicebus   `
 --name RootManageSharedAccessKey `
 --query primaryConnectionString

az servicebus queue create `
 --namespace-name laaz203sb `
 -g servicebus `
 -n testqueue 

New-AzureRmServiceBusQueue `
   -ResourceGroupName 65-40d36c20-using-azure-service-bus-queues-with-c `
 -NamespaceName laaz203sb `
 -name testqueue `
 -EnablePartitioning $false